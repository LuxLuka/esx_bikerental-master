resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

version '5.0'

description 'esx bike rental made by Sheen but edited by Lux'


client_scripts {
  '@es_extended/locale.lua',
  'translations/en.lua',
  --'warmenu.lua',
  'config.lua',
  'client.lua'
}

server_scripts {
	'@es_extended/locale.lua',
	'translations/en.lua',
	'config.lua',
	'server.lua'
}	
