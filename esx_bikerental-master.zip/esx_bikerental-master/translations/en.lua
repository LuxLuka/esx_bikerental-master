Locales['en'] = {
	['press_e'] = 'Press ~INPUT_CONTEXT~ rent a bike.',
	['storebike'] = 'Press ~INPUT_CONTEXT~ store bike back.',	
	['biketitle'] = 'Bike Rental',
	['bike'] = 'Bike - <span style="color:green;">TriBike</span> <span style="color:red;">89$</span>',
	['bike2'] = 'Bike - <span style="color:green;">Scorcher</span> <span style="color:red;">99$</span>',
	['bike3'] = 'Bike - <span style="color:green;">Cruiser</span> <span style="color:red;">129$</span>',
	['bike4'] = 'Bike - <span style="color:green;">BMX</span> <span style="color:red;">109$</span>',
	['bikefree'] = 'Bike - <span style="color:green;">TriBike</span>',
	['bike2free'] = 'Bike - <span style="color:green;">Scorcher</span>',
	['bike3free'] = 'Bike - <span style="color:green;">Cruiser</span>',
	['bike4free'] = 'Bike - <span style="color:green;">BMX</span>',
	['bikemessage'] = 'We hope you enjoyed the ride. Come back later. :)',
	['notabike'] = 'You are not on the bike!',
	
	['bike_pay'] = 'You paid: $%s',
	
	['bikes'] = '[Bikes]',
	
}
