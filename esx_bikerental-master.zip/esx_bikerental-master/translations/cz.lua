Locales['cz'] = {
	['press_e'] = 'Stiskni ~INPUT_CONTEXT~ a vypujci si kolo.',
	['storebike'] = 'Stiskni ~INPUT_CONTEXT~ a vrat vypujcene kolo.',
	['biketitle'] = 'Pujcovna kol',
	['bike'] = 'Kolo - <span style="color:green;">TriBike</span> <span style="color:red;">89$</span>',
	['bike2'] = 'Kolo - <span style="color:green;">Scorcher</span> <span style="color:red;">99$</span>',
	['bike3'] = 'Kolo - <span style="color:green;">Cruiser</span> <span style="color:red;">129$</span>',
	['bike4'] = 'Kolo - <span style="color:green;">BMX</span> <span style="color:red;">109$</span>',
	['bikefree'] = 'Bike - <span style="color:green;">TriBike</span>',
	['bike2free'] = 'Bike - <span style="color:green;">Scorcher</span>',
	['bike3free'] = 'Bike - <span style="color:green;">Cruiser</span>',
	['bike4free'] = 'Bike - <span style="color:green;">BMX</span>',
	['bikemessage'] = 'Doufáme ,že jste si jízdu užil. Děkujeme přidte zas. :)',
	['notabike'] = 'Nejsi na kole!',
	
	['bike_pay'] = 'Zaplatil jste: $%s',
	
	['bikes'] = '[Kola]',
	
}
